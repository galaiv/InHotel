$(function(){

    profile_picture_upload();
	
	company_logo_upload();
});