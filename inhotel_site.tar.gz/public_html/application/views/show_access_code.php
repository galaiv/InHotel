<div  class="grn_bg_in">
  <div class="container">
    <h2>Management</h2>
    <div class="mnu_sty">
    <ul>
    <li><a href="<?php echo base_url(); ?>activation_code">Activation Codes</a></li>
    
    </ul>
    </div>
  </div>
</div>

<div class="container gbg_in">
  <div class="row">
       <ol style="margin-bottom: 5px;background-color: #f0f0f0;" class="breadcrumb">
        <li><a href="<?php echo base_url(); ?>dashboard"><i class="fa fa-home"></i> </a></li>
         <li><a href="<?php echo base_url(); ?>activation_code">Activation Codes </a></li>
       
      </ol>
    <div class="col-md-6 portfolio-item" style="margin-bottom:40px;">
      <h4> Access to this hotel with this code</h4> <h3 style="margin-top:5px; text-transform:none;">Code: <?php echo $activation_code; ?><br/></h3>
      </div>
  </div>
  </div>
