<?php $this->load->view('header'); ?>

<div  class="grn_bg_in">
  <div class="container">
    <h2>CONTACT INFO</h2>
  </div>
</div>
<div class="container gbg_in">
  <div class="row">
    <h3>CONTACT INFO</h3>
    <br/>
	<div  style="">
		<b style="font-size:17px;">INHOTEL APP LTD<br/>
		20-22 WENLOCK ROAD<br/>
		LONDON<br/>
		ENGLAND<br/>
		N1 7GU</b></div>
    </div>
  <div class="col-lg-12 "><img src="<?php echo base_url();?>images/bg.jpg" width="100%"></div>
</div>
<?php $this->load->view('footer'); ?>