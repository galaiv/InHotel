<?php $this->load->view('admin/header'); ?>

<div  class="grn_bg_in">
  <div class="container">
    <h2>WELCOME TO YOUR ACCOUNT</h2>
  </div>
</div>
<div class="container gbg_in">
  <div class="row">
    <h3>YOUR ACCOUNT</h3>
    <br/>
    vehicula id in nibh. Donec aliquam dui turpis, at tempor purus fermentum ut. Etiam egestas rhoncus elit, et gravida eros vestibulum sit amet. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed interdum tempor nisl sed egestas. Ut quam sem, interdum nec nulla eget, commodo tincidunt arcu. Cras commodo sodales erat, vitae ullamcorper justo euismod quis.
    
    Sed congue quam vel ligula posuere finibus ac id quam. Sed in magna scelerisque, placerat felis sed, aliquam metus. Aenean id velit vel arcu ultrices dignissim eu vitae erat. Morbi fermentum risus nunc, sed tincidunt turpis ultrices at. In malesuada felis eget ultrices suscipit. Curabitur pellentesque velit at aliquet gravida. Quisque aliquet ligula sed interdum bibendum. Maecenas sed neque eu velit condimentum rhoncus. Pellentesque mattis scelerisque lorem et malesuada.
    
    Fusce commodo pharetra ullamcorper. Mauris vel orci eu sapien pretium porta. Nam eget dui vehicula quam egestas varius. In tincidunt dolor hendrerit semper fermentum. Vestibulum egestas nulla metus, vel tempus nibh convallis a. Ut aliquet eros risus, ut blandit neque molestie aliquam. Aliquam ac dictum libero. Quisque rutrum tristique feugiat. Maecenas nec dolor et est vulputate faucibus.
    
    Fusce rhoncus nisi vel tempor vestibulum. Vestibulum malesuada a purus a commodo. Etiam viverra, arcu et blandit lobortis, neque libero aliquam tortor, auctor posuere ipsum arcu sed leo. Donec ultricies elementum ante, in iaculis erat pretium in. Vivamus gravida tortor risus, id tincidunt nulla porta et. Nulla ac erat ut nisi placerat porta non eu augue. Cras auctor lorem a convallis varius. Quisque id justo ultricies metus tincidunt rutrum at nec nibh. Vestibulum eros lectus, tempus eu ultrices vitae, tempor eu lectus. Vivamus consequat dolor et arcu tempor sollicitudin. Morbi in tincidunt lectus, in vulputate tellus. Nullam laoreet, ligula nec rhoncus tempor, diam leo varius nunc, ut volutpat dui mi vitae ante. In venenatis e</div>
  <div class="col-lg-12 "><img src="<?php echo base_url();?>images/bg.jpg" width="100%"></div>
</div>
<?php $this->load->view('admin/footer'); ?>