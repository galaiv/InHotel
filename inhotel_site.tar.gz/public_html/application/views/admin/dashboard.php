<div class="bred_outer"><div class="bred_nav">
	<ul>
		<li><img src="<?php echo base_url()?>public/images/br_home.jpg" class="bn_home" /></li>
		<li>Dashboard</li>
	</ul>
</div></div>

<div class="container_out"></div>
<div class="container">
<div class="landing_out">
	<ul>	
            <li><a href="<?=base_url()?>admin/member/index/2" class="hotel_ico">Hotel Management</a></li>
            <li><a href="<?=base_url()?>admin/member/index/1" class="user_ico">Member Management</a></li>
            <li><a href="<?=base_url()?>admin/access_management/" class="access_ico">Access Management</a></li>
            <li><a href="<?=base_url()?>admin/drinks" class="drinks_ico">Drinks Management</a></li>
            <li><a href="<?=base_url()?>admin/order/" class="order_ico">Orders Management</a></li>
		<li><a href="<?=base_url()?>admin/feedback" class="feedback_ico">Feedbacks Management</a></li>
		<!--<li><a href="<?php echo base_url()?>admin/admin_dashboard/adminPreferences/" class="genere_ico">Configuration</a></li>-->
	</ul>
</div>