<div class="mne_footer">© <?php echo date("Y")?> InHotel</strong></div>
</body>
</html>