
<div class="bred_outer"><div class="bred_nav">
<ul>
<li ><a href="#" ><img src="<?php echo base_url();?>public/images/br_home.jpg" class="bn_home" /></a></li>

<li><a href="<?php echo base_url();?>admin/admin_dashboard">Home</a></li>
<li><img src="<?=base_url()?>public/images/br_arow.jpg" class="bn_arow" /></li>
<li><a style="color: #1a91ec;" href="<?php echo base_url();?>admin/members/user_home">Dashboard</a></li>

</ul>
</div></div>
<div class="container_out"></div>
<div class="container">
<div class="landing_out"><ul>
<li><a href="<?php echo base_url();?>admin/member/index/2" class="muncher_ico">Customer</a></li>
<!--<li><a href="<?php echo base_url();?>admin/member/index/3" class="restarateur_ico">Business</a></li>-->

</ul></div>
