
Your New Password is <?php echo $dtls['new_password'];?>



 Rotolegends team
