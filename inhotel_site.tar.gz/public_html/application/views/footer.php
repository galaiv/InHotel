<div id="footer">
  <div class="container">
    <div class="col-lg-10 col-md-push-1 pds"> <span class="pull-left flwd"> &reg; 2015 <a title="" href="<?php echo base_url();?>">In Hotel</a> - All rights reserved</span>
      <p class="pull-right flwd"> <a href="<?php echo base_url();?>">home</a>
	   &nbsp;-&nbsp;<a  href="<?php echo base_url();?>privacy">privacy</a> 
	   &nbsp;-&nbsp;<a  href="<?php echo base_url();?>legal_notes">legal notes</a> 
	   &nbsp;-&nbsp;<a href="<?php echo base_url();?>contact">contacts</a>
	    &nbsp;-&nbsp;<a  target="_blank" href="https://www.facebook.com/inhotelapp">Facebook</a>
		 &nbsp;-&nbsp;<a  target="_blank" href="https://twitter.com/i/notifications">Twitter</a>
	    </p>
    </div>
  </div>
</div>
</body>
</html>
