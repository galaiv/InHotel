<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// You MailChimp API Key
// Obtained by logging into your MailChimp account and navigating to 'Account > API Keys and Info'
//$config['mcapi_apikey'] = 'b668102b344326c3b7f70222efd43b52-us3';

$config['mcapi_secure'] = false;