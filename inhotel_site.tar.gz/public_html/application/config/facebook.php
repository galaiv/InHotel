<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//QA Duzz2 == manurs1987@gmail.com
/*$config['appID']		= '285391288314250';
$config['appSecret']	= '882c5e86a59f1736e66c9451fd95c1e0';*/

//Local	== umesh@newagesmb.com
$config['appID']		= '1401466543468346';
$config['appSecret']	= '1652e702aec1bcf7aa0d7caf01d6ef6c';

//QA Duzz == manu@newagesmb.com
//$config['appID']		= '868932493125749';
//$config['appSecret']	= '30f006b464253a36dd5ad6a422d9c245';

/* End of file facebook.php */
/* Location: ./application/config/facebook.php */
?>