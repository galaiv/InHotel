<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * reCaptcha File Config
 *
 * File     : recaptcha.php
 * Created  : May 14, 2013 | 4:22:40 PM
 * 
 * Author   : Andi Irwandi Langgara <irwandi@ourbluecode.com>
 */

$config['public_key']   = '6LcYHOkSAAAAAP4_p6u-iqJmtFVnZC72zaMEbruw';
$config['private_key']  = '6LcYHOkSAAAAAOLAjHvomIa0CYc4qSjHqV5PzI6k';
// Set Recaptcha theme, default red (red/white/blackglass/clean)
$config['recaptcha_theme']  = 'red';

?>
